#!/bin/bash

javac DistTask.java
javac MCPi.java
