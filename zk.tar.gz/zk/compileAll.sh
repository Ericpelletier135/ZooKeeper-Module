cd task
./compiletask.sh
cd ../clnt
./compileclnt.sh
cd ../dist
./compilesrvr.sh
cd ..