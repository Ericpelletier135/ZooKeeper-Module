export ZOOBINDIR=~/courses/COMP512/A3/apache-zookeeper-3.6.2-bin/bin
. $ZOOBINDIR/zkEnv.sh